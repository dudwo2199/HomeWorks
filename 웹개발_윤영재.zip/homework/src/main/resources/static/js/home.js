const overlayTag = document.querySelector('#overlay');
const questionData = document.querySelector('#question-data');
const questionContent = document.querySelector('#question-content-panel');

function openPanel(qno) {

    fetch("http://localhost/lookat", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `qno=${qno}`
    })
        .then(res => res.json())
        .then(data => {
            questionData.innerHTML = `
                <strong>제목:</strong> ${data.title}<br>
                <strong>상태:</strong> ${data.stateIdx}<br>
                <strong>작성자:</strong> ${data.userNick}<br>
                <strong>작성일시:</strong> ${data.createdDate}
            `;

            questionContent.innerHTML = `
                <strong>${data.content}</strong> 
            `;
            return 'open';
        }).then(value => {

            overlayTag.classList.add(value);
            document.body.style.overflow = 'hidden';
        })
        .catch(error => {
            console.error('error: ' + error);
        });
};

function closePanel() {
    localStorage.removeItem("uno");
    overlayTag.classList.remove('open'); // 패널 닫기
    document.body.style.overflow = '';
};

overlayTag.addEventListener('click', (t) => {
    if (t.target === overlayTag)
        closePanel();
});

document.addEventListener('keydown', (keyevent) => {
    if (keyevent.key === 'Escape') {
        if (overlayTag.classList.contains('open'))
            closePanel();
    }
});

