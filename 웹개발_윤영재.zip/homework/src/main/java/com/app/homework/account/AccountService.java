package com.app.homework.account;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountService {
    @Autowired
    private AccountMapper mapper;

    public int signup(AccountVo vo){
        return mapper.signup(vo);
    }

    public AccountVo signin(AccountVo vo){
        return mapper.signin(vo);
    }
}
