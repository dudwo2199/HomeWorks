package com.app.homework.account;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface AccountMapper {

    @Insert("""
            INSERT INTO USERS(UNO, USERID, USERPW, USERNICK) VALUES (SEQ_USER.NEXTVAL, #{userId}, #{userPw}, #{userNick}) 
            """)
    int signup(AccountVo vo);

    @Select("""
            SELECT 
                *
            FROM
                USERS
            WHERE
                USERID = #{userId}
                AND USERPW = #{userPw}
                AND DELETE_DATE IS NULL
            """)
    AccountVo signin(AccountVo vo);
}
