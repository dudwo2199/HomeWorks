package com.app.homework.account;

import lombok.Data;

@Data
public class AccountVo {
    private String uno;
    private String userId;
    private String userPw;
    private String userNick;
    private String createDate;
    private String deleteDate;
}