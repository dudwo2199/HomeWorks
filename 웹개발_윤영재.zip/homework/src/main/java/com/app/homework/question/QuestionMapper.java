package com.app.homework.question;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface QuestionMapper {
    @Select("""
            SELECT
                QNO
                , (SELECT USERNICK FROM USERS WHERE USERS.UNO = QUESTIONS.UNO) AS USERNICK
                , TITLE
                , CREATED_DATE
                , STATE_IDX
            FROM
                QUESTIONS
            ORDER BY QNO DESC
            """)
    List<QuestionVo> lookup();

    @Insert("""
            INSERT INTO QUESTIONS (QNO, UNO, TITLE, CONTENT) VALUES(SEQ_QUESTION.NEXTVAL, #{uno}, #{title}, #{content})
            """)
    int write(QuestionVo vo);
}
