package com.app.homework.question;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class QuestionVo {
    @JsonProperty("qno")
    private String qno;
    @JsonProperty("uno")
    private String uno;
    @JsonProperty("userNick")
    private String userNick;
    @JsonProperty("title")
    private String title;
    @JsonProperty("content")
    private String content;
    @JsonProperty("createdDate")
    private String createdDate;
    @JsonProperty("updateDate")
    private String updateDate;
    @JsonProperty("stateIdx")
    private String stateIdx;
}
