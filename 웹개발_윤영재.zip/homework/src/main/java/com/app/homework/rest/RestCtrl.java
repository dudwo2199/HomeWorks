package com.app.homework.rest;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestCtrl {

    @Autowired
    private RestMapper mapper;

    @PostMapping("/lookat")
    public String lookAt(String qno) throws Exception {
        System.out.println("call lookat" + qno);
        var result = mapper.lookat(qno);

        System.out.println(result);
        return new ObjectMapper().writeValueAsString(result);
    }
}
