package com.app.homework.question.controller;

import com.app.homework.account.AccountVo;
import com.app.homework.question.QuestionService;
import com.app.homework.question.QuestionVo;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@Controller
@RequestMapping("/question")
public class QuestionCtrl {

    @Autowired
    private QuestionService service;

    @GetMapping("/write")
    public void write(){}

    @PostMapping("/write")
    public String write(QuestionVo vo, HttpSession session){
        var loginVo = (AccountVo) session.getAttribute("vlogin");

        if(loginVo == null)
            return "redirect:/home";

        vo.setUno(loginVo.getUno());
        var result = service.write(vo);

        System.out.println("result = " + result);
        System.out.println("vo = " + vo);

        if(result != 1)
            throw new IllegalStateException("ERROR-CODE[Q003] - write failed..");

        return "redirect:/home";
    }
}
