package com.app.homework.account.controller;

import com.app.homework.account.AccountService;
import com.app.homework.account.AccountVo;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/account")
public class AccountCtrl {
    @Autowired
    private AccountService service;

    @GetMapping("/signup")
    public void signup(){}

    @PostMapping("/signup")
    public String signup(AccountVo vo){

        var result = service.signup(vo);

        if(result != 1)
            throw new IllegalStateException("ERROR-CODE[M001] join failed");

        return "redirect:/home";
    }

    @PostMapping("/signin")
    public String signin(AccountVo vo, HttpSession session){
        var result = service.signin(vo);

        if(result == null)
            throw new IllegalStateException("ERROR-CODE[M002] login failed");

        session.setAttribute("vlogin", result);
        return "redirect:/home";
    }

    @GetMapping("/signout")
    public String signout(HttpSession session){
        session.invalidate();
        return "redirect:/home";
    }
}
