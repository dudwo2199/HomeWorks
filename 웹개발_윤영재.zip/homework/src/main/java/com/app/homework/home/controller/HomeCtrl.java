package com.app.homework.home.controller;

import com.app.homework.question.QuestionService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeCtrl {

    @Autowired
    private QuestionService service;

    @GetMapping("/home")
    public void home(HttpSession session) {
        var result = service.lookup();

        if (result == null)
            throw new IllegalStateException("ERROR-CODE[Q001] lookup failed");

        session.setAttribute("vList", result);
    }
}
