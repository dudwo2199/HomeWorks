package com.app.homework.rest;

import com.app.homework.question.QuestionVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface RestMapper {
    @Select("""
            SELECT
                QNO
                , UNO
                , (SELECT USERNICK FROM USERS WHERE USERS.UNO = QUESTIONS.UNO) AS USERNICK
                , TITLE
                , CONTENT
                , CREATED_DATE
                , STATE_IDX
            FROM
                QUESTIONS
            WHERE
                QNO = #{qno}
            """)
    QuestionVo lookat(String qno);
}
